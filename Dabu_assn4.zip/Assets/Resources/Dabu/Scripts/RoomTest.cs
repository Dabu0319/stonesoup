using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RoomTest : Room
{
    
    public GameObject pickUpTest;
    public GameObject apt283Shield;
    

    
    
    // Start is called before the first frame update
    void Start()
    {
        
        //Tile.spawnTile(pickUpTest, transform, (int)0, (int)0);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
